class Posts{
  String image, description, date, time;
  Posts(this.image , this.description , this.date , this.time);
}